<?php $__env->startSection('title', 'Detail Pengaduan: ' . $aspiration->ticket_number); ?>
<?php $__env->startSection('page-title', 'Detail & Tindak Lanjut Pengaduan'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3 d-flex flex-wrap align-items-center justify-content-between gap-2">
    <a href="<?php echo e(route('admin.aspirasi.index')); ?>" class="btn btn-sm btn-outline-secondary rounded-pill bg-white">
        <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar
    </a>

    <div class="d-flex align-items-center gap-2">
        <span class="text-muted small">Status Saat Ini:</span>
        <span class="badge-status badge-status-<?php echo e($aspiration->status); ?>">
            <i class="bi <?php echo e($aspiration->getStatusIcon()); ?>"></i> <?php echo e($aspiration->status); ?>

        </span>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Complaint Details & Media -->
    <div class="col-lg-8">
        <!-- Main Info Card -->
        <div class="card sc-card mb-4">
            <div class="card-header bg-white py-3 border-bottom d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-primary fs-6 font-monospace"><?php echo e($aspiration->ticket_number); ?></span>
                    <span class="badge bg-secondary-subtle text-secondary">
                        <i class="bi <?php echo e($aspiration->category->icon ?? 'bi-tag'); ?> me-1"></i> <?php echo e($aspiration->category->name); ?>

                    </span>
                </div>
                <div class="text-muted small">
                    <i class="bi bi-clock me-1"></i> <?php echo e($aspiration->created_at->translatedFormat('d F Y, H:i')); ?> WIB
                </div>
            </div>
            <div class="card-body">
                <h4 class="fw-bold text-dark mb-3"><?php echo e($aspiration->title); ?></h4>

                <div class="p-3 bg-light rounded-3 mb-4 border">
                    <div class="row g-2">
                        <div class="col-sm-6">
                            <div class="text-muted small">Lokasi Sarana / Fasilitas:</div>
                            <div class="fw-semibold text-dark">
                                <i class="bi bi-geo-alt-fill text-danger me-1"></i> <?php echo e($aspiration->location); ?>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="text-muted small">Kategori Sarpras:</div>
                            <div class="fw-semibold text-dark">
                                <i class="bi bi-folder-fill text-primary me-1"></i> <?php echo e($aspiration->category->name); ?>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <h6 class="fw-bold text-dark mb-2">Deskripsi Kerusakan / Kendala:</h6>
                    <div class="p-3 border rounded-3 bg-white" style="white-space: pre-line; line-height: 1.7;">
                        <?php echo e($aspiration->description); ?>

                    </div>
                </div>

                <!-- Photo Evidence -->
                <div>
                    <h6 class="fw-bold text-dark mb-2">Foto Bukti Kerusakan:</h6>
                    <?php if($aspiration->photo): ?>
                        <div class="border rounded-3 p-2 bg-light d-inline-block">
                            <img src="<?php echo e($aspiration->photo_url); ?>" 
                                 alt="Bukti Pengaduan" 
                                 class="img-fluid rounded" 
                                 style="max-height: 320px; object-fit: contain; cursor: pointer;"
                                 data-bs-toggle="modal" 
                                 data-bs-target="#photoModal">
                            <div class="text-center mt-2">
                                <button type="button" class="btn btn-sm btn-outline-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#photoModal">
                                    <i class="bi bi-zoom-in me-1"></i> Klik untuk Perbesar Foto
                                </button>
                            </div>
                        </div>

                        <!-- Modal for enlarged photo -->
                        <div class="modal fade" id="photoModal" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h6 class="modal-title fw-bold">Foto Bukti Pengaduan - <?php echo e($aspiration->ticket_number); ?></h6>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center p-2 bg-dark">
                                        <img src="<?php echo e($aspiration->photo_url); ?>" alt="Bukti Foto" class="img-fluid rounded">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-light border text-muted small mb-0">
                            <i class="bi bi-info-circle me-1"></i> Tidak ada lampiran foto bukti yang diunggah oleh siswa.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Feedback & Responses Section -->
        <div class="card sc-card mb-4">
            <div class="card-header bg-white py-3 border-bottom d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-chat-left-dots text-primary fs-5"></i>
                    <h6 class="mb-0 fw-bold">Tanggapan / Umpan Balik Admin (<?php echo e($aspiration->feedbacks->count()); ?>)</h6>
                </div>
            </div>
            <div class="card-body">
                <!-- Add Feedback Form -->
                <form action="<?php echo e(route('admin.aspirasi.feedback', $aspiration->id)); ?>" method="POST" class="mb-4">
                    <?php echo csrf_field(); ?>
                    <div class="mb-2">
                        <label for="response" class="form-label fw-semibold small text-muted">Beri Tanggapan Resmi kepada Siswa:</label>
                        <textarea name="response" 
                                  id="response" 
                                  rows="3" 
                                  class="form-control <?php $__errorArgs = ['response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  placeholder="Tuliskan pesan konfirmasi, arahan, atau progres perbaikan untuk pelapor..." 
                                  required><?php echo e(old('response')); ?></textarea>
                        <?php $__errorArgs = ['response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="text-end">
                        <button type="submit" class="btn btn-primary btn-sm px-3" style="background-color: var(--sc-blue); border-color: var(--sc-blue);">
                            <i class="bi bi-send me-1"></i> Kirim Umpan Balik
                        </button>
                    </div>
                </form>

                <!-- Feedback List -->
                <div class="d-flex flex-column gap-3">
                    <?php $__empty_1 = true; $__currentLoopData = $aspiration->feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-3 rounded-3 border bg-light">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge bg-primary">Petugas Sarpras</span>
                                    <strong class="text-dark small"><?php echo e($fb->user->name); ?></strong>
                                </div>
                                <span class="text-muted small"><?php echo e($fb->created_at->diffForHumans()); ?> (<?php echo e($fb->created_at->format('d/m/Y H:i')); ?>)</span>
                            </div>
                            <p class="mb-0 text-dark small" style="white-space: pre-line;"><?php echo e($fb->response); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-muted py-3 small">
                            <i class="bi bi-chat-square text-secondary d-block fs-4 mb-1"></i>
                            Belum ada umpan balik yang diberikan untuk pengaduan ini.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Status Change Timeline History -->
        <div class="card sc-card">
            <div class="card-header bg-white py-3 border-bottom d-flex align-items-center gap-2">
                <i class="bi bi-clock-history text-info fs-5"></i>
                <h6 class="mb-0 fw-bold">Histori Perubahan Status Pengaduan</h6>
            </div>
            <div class="card-body">
                <div class="timeline-sc">
                    <?php $__empty_1 = true; $__currentLoopData = $aspiration->statusHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="timeline-item">
                            <div class="timeline-dot"></div>
                            <div class="timeline-content">
                                <div class="d-flex flex-wrap align-items-center justify-content-between gap-1 mb-1">
                                    <div>
                                        <?php if($hist->previous_status): ?>
                                            <span class="badge bg-secondary-subtle text-secondary small"><?php echo e($hist->previous_status); ?></span>
                                            <i class="bi bi-arrow-right mx-1 small text-muted"></i>
                                        <?php endif; ?>
                                        <span class="badge-status badge-status-<?php echo e($hist->new_status); ?>">
                                            <?php echo e($hist->new_status); ?>

                                        </span>
                                    </div>
                                    <small class="text-muted"><?php echo e($hist->created_at->translatedFormat('d M Y, H:i')); ?> WIB</small>
                                </div>
                                <p class="mb-1 text-dark small"><?php echo e($hist->notes); ?></p>
                                <div class="text-muted" style="font-size: 0.75rem;">
                                    Oleh: <strong><?php echo e($hist->user->name ?? 'Sistem'); ?></strong> 
                                    (<?php echo e($hist->user ? strtoupper($hist->user->role) : 'SYSTEM'); ?>)
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted small mb-0">Belum ada riwayat status tercatat.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Column: Student Info & Update Status Action -->
    <div class="col-lg-4">
        <!-- Update Status Card -->
        <div class="card sc-card mb-4 border-primary">
            <div class="card-header bg-primary text-white py-3">
                <h6 class="mb-0 fw-bold"><i class="bi bi-gear-fill me-2"></i> Perbarui Status Pengaduan</h6>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.aspirasi.update-status', $aspiration->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="status" class="form-label fw-semibold small text-muted">Pilih Status Baru:</label>
                        <select name="status" id="status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="Menunggu" <?php echo e($aspiration->status === 'Menunggu' ? 'selected' : ''); ?>>1. Menunggu (Verifikasi Awal)</option>
                            <option value="Diproses" <?php echo e($aspiration->status === 'Diproses' ? 'selected' : ''); ?>>2. Diproses (Teknisi Bekerja)</option>
                            <option value="Selesai" <?php echo e($aspiration->status === 'Selesai' ? 'selected' : ''); ?>>3. Selesai (Perbaikan Tuntas)</option>
                            <option value="Ditolak" <?php echo e($aspiration->status === 'Ditolak' ? 'selected' : ''); ?>>4. Ditolak (Tidak Layak/Batal)</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="notes" class="form-label fw-semibold small text-muted">Catatan Log Histori:</label>
                        <input type="text" 
                               name="notes" 
                               id="notes" 
                               class="form-control form-control-sm" 
                               placeholder="Contoh: Teknisi sedang mengganti komponen...">
                        <div class="form-text small">Catatan ini akan muncul pada jejak histori timeline.</div>
                    </div>

                    <div class="mb-3">
                        <label for="feedback" class="form-label fw-semibold small text-muted">Kirim Tanggapan Tambahan (Opsional):</label>
                        <textarea name="feedback" 
                                  id="feedback" 
                                  rows="2" 
                                  class="form-control form-control-sm" 
                                  placeholder="Pesan tambahan yang dibaca siswa..."></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 fw-semibold" style="background-color: var(--sc-blue); border-color: var(--sc-blue);">
                        <i class="bi bi-check-lg me-1"></i> Simpan Pembaruan Status
                    </button>
                </form>
            </div>
        </div>

        <!-- Student Profile Card -->
        <div class="card sc-card mb-4">
            <div class="card-header bg-white py-3 border-bottom d-flex align-items-center gap-2">
                <i class="bi bi-person-badge text-primary fs-5"></i>
                <h6 class="mb-0 fw-bold">Informasi Siswa (Pelapor)</h6>
            </div>
            <div class="card-body">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div class="rounded-circle bg-light p-3 border text-primary fs-4">
                        <i class="bi bi-person"></i>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><?php echo e($aspiration->user->name); ?></h6>
                        <span class="badge bg-info-subtle text-info border">Siswa Aktif</span>
                    </div>
                </div>

                <ul class="list-group list-group-flush small">
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">NISN</span>
                        <strong class="text-dark"><?php echo e($aspiration->user->nisn ?? '-'); ?></strong>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">Kelas / Jurusan</span>
                        <strong class="text-dark"><?php echo e($aspiration->user->kelas ?? '-'); ?></strong>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">Alamat Email</span>
                        <span class="text-dark"><?php echo e($aspiration->user->email); ?></span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">No. WhatsApp</span>
                        <span class="text-dark"><?php echo e($aspiration->user->phone ?? '-'); ?></span>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Danger Zone Delete -->
        <div class="card sc-card border-danger-subtle bg-danger-subtle bg-opacity-25">
            <div class="card-body p-3">
                <h6 class="fw-bold text-danger mb-1"><i class="bi bi-trash me-1"></i> Hapus Pengaduan</h6>
                <p class="small text-muted mb-2">Hapus pengaduan ini secara permanen dari sistem jika merupakan laporan spam atau duplikat.</p>
                <form action="<?php echo e(route('admin.aspirasi.destroy', $aspiration->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" 
                            class="btn btn-outline-danger btn-sm w-100 btn-confirm-delete"
                            data-confirm="PERINGATAN: Apakah Anda benar-benar yakin ingin menghapus pengaduan nomor <?php echo e($aspiration->ticket_number); ?> beserta seluruh histori dan responnya?">
                        Hapus Pengaduan Permanen
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Anindia WelanLestari\Downloads\pengaduan-sarana-sekolah\rahma_project\resources\views/admin/aspirations/show.blade.php ENDPATH**/ ?>