<?php $__env->startSection('title', 'Manajemen Aspirasi Siswa'); ?>
<?php $__env->startSection('page-title', 'Manajemen Pengaduan Sarana'); ?>

<?php $__env->startSection('content'); ?>
<!-- Status Quick Filter Buttons -->
<div class="d-flex flex-wrap gap-2 mb-3">
    <a href="<?php echo e(route('admin.aspirasi.index', request()->except('status', 'page'))); ?>" 
       class="btn btn-sm <?php echo e(!request('status') ? 'btn-primary' : 'btn-outline-secondary bg-white'); ?> rounded-pill px-3">
        Semua (<?php echo e($counts['total']); ?>)
    </a>
    <a href="<?php echo e(route('admin.aspirasi.index', array_merge(request()->except('page'), ['status' => 'Menunggu']))); ?>" 
       class="btn btn-sm <?php echo e(request('status') === 'Menunggu' ? 'btn-warning' : 'btn-outline-warning text-dark bg-white'); ?> rounded-pill px-3">
        Menunggu (<?php echo e($counts['menunggu']); ?>)
    </a>
    <a href="<?php echo e(route('admin.aspirasi.index', array_merge(request()->except('page'), ['status' => 'Diproses']))); ?>" 
       class="btn btn-sm <?php echo e(request('status') === 'Diproses' ? 'btn-primary' : 'btn-outline-primary bg-white'); ?> rounded-pill px-3">
        Diproses (<?php echo e($counts['diproses']); ?>)
    </a>
    <a href="<?php echo e(route('admin.aspirasi.index', array_merge(request()->except('page'), ['status' => 'Selesai']))); ?>" 
       class="btn btn-sm <?php echo e(request('status') === 'Selesai' ? 'btn-success' : 'btn-outline-success bg-white'); ?> rounded-pill px-3">
        Selesai (<?php echo e($counts['selesai']); ?>)
    </a>
    <a href="<?php echo e(route('admin.aspirasi.index', array_merge(request()->except('page'), ['status' => 'Ditolak']))); ?>" 
       class="btn btn-sm <?php echo e(request('status') === 'Ditolak' ? 'btn-danger' : 'btn-outline-danger bg-white'); ?> rounded-pill px-3">
        Ditolak (<?php echo e($counts['ditolak']); ?>)
    </a>
</div>

<!-- Search & Advanced Filter Card -->
<div class="card sc-card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('admin.aspirasi.index')); ?>" method="GET" class="row g-2 align-items-end">
            <!-- Keyword Search -->
            <div class="col-md-3">
                <label for="q" class="form-label small fw-semibold text-muted">Pencarian Kata Kunci</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" 
                           name="q" 
                           id="q" 
                           class="form-control form-control-sm" 
                           value="<?php echo e(request('q')); ?>" 
                           placeholder="Tiket, judul, nama siswa...">
                </div>
            </div>

            <!-- Category Filter -->
            <div class="col-md-2">
                <label for="category_id" class="form-label small fw-semibold text-muted">Kategori Fasilitas</label>
                <select name="category_id" id="category_id" class="form-select form-select-sm">
                    <option value="">-- Semua Kategori --</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>>
                            <?php echo e($cat->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Student Filter -->
            <div class="col-md-2">
                <label for="user_id" class="form-label small fw-semibold text-muted">Filter Siswa</label>
                <select name="user_id" id="user_id" class="form-select form-select-sm">
                    <option value="">-- Semua Siswa --</option>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($st->id); ?>" <?php echo e(request('user_id') == $st->id ? 'selected' : ''); ?>>
                            <?php echo e($st->name); ?> (<?php echo e($st->kelas ?? 'Siswa'); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Date Filter -->
            <div class="col-md-2">
                <label for="date" class="form-label small fw-semibold text-muted">Filter Tanggal</label>
                <input type="date" 
                       name="date" 
                       id="date" 
                       class="form-control form-control-sm" 
                       value="<?php echo e(request('date')); ?>">
            </div>

            <!-- Month Filter -->
            <div class="col-md-2">
                <label for="month" class="form-label small fw-semibold text-muted">Filter Bulan</label>
                <input type="month" 
                       name="month" 
                       id="month" 
                       class="form-control form-control-sm" 
                       value="<?php echo e(request('month')); ?>">
            </div>

            <!-- Action Buttons -->
            <div class="col-md-1 d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm w-100" title="Terapkan Filter" style="background-color: var(--sc-blue); border-color: var(--sc-blue);">
                    <i class="bi bi-filter"></i>
                </button>
                <a href="<?php echo e(route('admin.aspirasi.index')); ?>" class="btn btn-light btn-sm border" title="Reset Filter">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Main Table Card -->
<div class="card sc-card">
    <div class="card-header bg-white py-3 d-flex align-items-center justify-content-between border-bottom">
        <div class="fw-bold text-dark">
            <i class="bi bi-table text-primary me-1"></i> Data Pengaduan Sarana Sekolah (<?php echo e($aspirations->total()); ?>)
        </div>
        <small class="text-muted">Halaman <?php echo e($aspirations->currentPage()); ?> dari <?php echo e($aspirations->lastPage()); ?></small>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sc table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 120px;">No. Tiket</th>
                        <th style="width: 180px;">Pelapor (Siswa)</th>
                        <th>Kategori & Lokasi</th>
                        <th>Judul Pengaduan</th>
                        <th>Foto</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th class="text-end" style="width: 120px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $aspirations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspiration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <span class="badge bg-light text-dark border font-monospace"><?php echo e($aspiration->ticket_number); ?></span>
                            </td>
                            <td>
                                <div class="fw-semibold text-dark"><?php echo e($aspiration->user->name); ?></div>
                                <small class="text-muted">NISN: <?php echo e($aspiration->user->nisn ?? '-'); ?> | <?php echo e($aspiration->user->kelas ?? '-'); ?></small>
                            </td>
                            <td>
                                <span class="badge bg-secondary-subtle text-secondary mb-1">
                                    <i class="bi <?php echo e($aspiration->category->icon ?? 'bi-tag'); ?> me-1"></i> <?php echo e($aspiration->category->name); ?>

                                </span>
                                <div class="small text-muted text-truncate" style="max-width: 180px;" title="<?php echo e($aspiration->location); ?>">
                                    <i class="bi bi-geo-alt me-1 text-danger"></i> <?php echo e($aspiration->location); ?>

                                </div>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.aspirasi.show', $aspiration->id)); ?>" class="fw-semibold text-dark text-decoration-none hover-primary">
                                    <?php echo e($aspiration->title); ?>

                                </a>
                                <div class="small text-muted text-truncate" style="max-width: 280px;" title="<?php echo e($aspiration->description); ?>">
                                    <?php echo e(Str::limit($aspiration->description, 60)); ?>

                                </div>
                            </td>
                            <td>
                                <?php if($aspiration->photo): ?>
                                    <a href="<?php echo e($aspiration->photo_url); ?>" target="_blank" class="badge bg-primary-subtle text-primary text-decoration-none">
                                        <i class="bi bi-image me-1"></i> Foto
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge-status badge-status-<?php echo e($aspiration->status); ?>">
                                    <i class="bi <?php echo e($aspiration->getStatusIcon()); ?>"></i> <?php echo e($aspiration->status); ?>

                                </span>
                            </td>
                            <td>
                                <div class="small text-dark"><?php echo e($aspiration->created_at->format('d/m/Y')); ?></div>
                                <small class="text-muted"><?php echo e($aspiration->created_at->format('H:i')); ?> WIB</small>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.aspirasi.show', $aspiration->id)); ?>" class="btn btn-outline-primary" title="Tindak Lanjut & Detail">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.aspirasi.destroy', $aspiration->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" 
                                                class="btn btn-outline-danger btn-confirm-delete" 
                                                data-confirm="Apakah Anda yakin ingin menghapus pengaduan nomor <?php echo e($aspiration->ticket_number); ?>?"
                                                title="Hapus Data">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                <i class="bi bi-search fs-1 d-block text-secondary mb-2"></i>
                                <h5>Tidak Ada Data Pengaduan Ditemukan</h5>
                                <p class="small mb-0">Coba ubah kriteria pencarian atau atur ulang filter Anda.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if($aspirations->hasPages()): ?>
        <div class="card-footer bg-white py-3 border-top d-flex justify-content-end">
            <?php echo e($aspirations->links('pagination::bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Anindia WelanLestari\Downloads\pengaduan-sarana-sekolah\rahma_project\resources\views/admin/aspirations/index.blade.php ENDPATH**/ ?>