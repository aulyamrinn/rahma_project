<?php $__env->startSection('title', 'Masuk ke Sistem'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('login')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label for="login" class="form-label fw-semibold small text-muted">Email atau NISN</label>
        <div class="input-group">
            <span class="input-group-text bg-light"><i class="bi bi-person text-secondary"></i></span>
            <input type="text" 
                   name="login" 
                   id="login" 
                   class="form-control <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   value="<?php echo e(old('login')); ?>" 
                   placeholder="Masukkan email atau NISN..." 
                   required 
                   autofocus>
        </div>
        <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label fw-semibold small text-muted">Kata Sandi (Password)</label>
        <div class="input-group">
            <span class="input-group-text bg-light"><i class="bi bi-lock text-secondary"></i></span>
            <input type="password" 
                   name="password" 
                   id="password" 
                   class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   placeholder="Masukkan kata sandi..." 
                   required>
        </div>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label class="form-check-label small text-muted" for="remember">
                Ingat Sesi Saya
            </label>
        </div>
    </div>

    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold shadow-sm mb-3" style="background-color: var(--sc-blue); border-color: var(--sc-blue);">
        <i class="bi bi-box-arrow-in-right me-1"></i> Masuk Sekarang
    </button>

    <div class="text-center small text-muted mb-4">
        Belum memiliki akun siswa? 
        <a href="<?php echo e(route('register')); ?>" class="text-primary fw-semibold text-decoration-none">Daftar Akun Baru</a>
    </div>

    <!-- Quick Fill Demo Accounts for UKK Reviewers -->
    <div class="p-3 bg-light rounded-3 border">
        <div class="d-flex align-items-center justify-content-between mb-2">
            <span class="fw-bold text-dark small"><i class="bi bi-key-fill text-warning me-1"></i> Akun Pengujian (Demo UKK):</span>
        </div>
        <div class="d-grid gap-2">
            <button type="button" 
                    class="btn btn-outline-dark btn-sm text-start d-flex justify-content-between align-items-center"
                    onclick="quickFillLogin('admin@schoolcare.sch.id', 'password')">
                <span><i class="bi bi-shield-lock me-1 text-danger"></i> <strong>Admin:</strong> admin@schoolcare.sch.id</span>
                <span class="badge bg-secondary">Isi Otomatis</span>
            </button>
            <button type="button" 
                    class="btn btn-outline-primary btn-sm text-start d-flex justify-content-between align-items-center"
                    onclick="quickFillLogin('ahmad@siswa.schoolcare.sch.id', 'password')">
                <span><i class="bi bi-person me-1 text-primary"></i> <strong>Siswa:</strong> ahmad@siswa.schoolcare.sch.id</span>
                <span class="badge bg-secondary">Isi Otomatis</span>
            </button>
        </div>
        <div class="text-center mt-2 text-muted" style="font-size: 0.75rem;">
            Default Password: <code>password</code>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Anindia WelanLestari\Downloads\pengaduan-sarana-sekolah\rahma_project\resources\views/auth/login.blade.php ENDPATH**/ ?>